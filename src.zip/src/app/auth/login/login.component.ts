import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Assets, Regex, RouteNames, LOCAL_KEY, FAICONS } from '../../_constants';
import { MyErrorStateMatcher, setLocalStorage } from '../../helpers';
import { CommonService, UserService } from '../../_services';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup | any;
  matcher = new MyErrorStateMatcher();
  files: any = Assets;
  hidePassword = true;
  faIcon: any = FAICONS;

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private commonService: CommonService
  ) { }

  ngOnInit(): void {
    this.initializeForm();
  }

  /**
   * Initially load form
   */
  initializeForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(Regex.email)]],
      password: ['', Validators.required],
    });
  }

  get loginFG() {
    return this.loginForm.controls;
  }

  togglePasswordVisibility() {
    this.hidePassword = !this.hidePassword;
  }


  /**
   * On submit to login
   */
  onSubmit() {
    this.userService.login(this.loginForm.value).subscribe((res: any) => {
      this.commonService.emitValueForSpinner();
      this.commonService.toaster(res);
      if (res.success) {
        setLocalStorage(LOCAL_KEY.USER_DETAILS, res.data[0]);
        setLocalStorage(LOCAL_KEY.TOKEN, res.token);
        setTimeout(() => {
          location.href = RouteNames.DASHBOARD;
        }, 600);
      }
    });
  }
}
