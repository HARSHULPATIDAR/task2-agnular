import { FAICONS } from ".";

export enum RouteNames {
    LOGIN = '/auth/login',
    DASHBOARD = '/dashboard',
    USER = '/users',
    USER_ADD = '/users/add',
    USER_UPDATE = '/users/edit/',

};

export enum MenuName {
    DASHBOARD = 'Dashboard',
    USER = 'Users',
  
};

export enum Slug {
    DASHBOARD = 'dashboard',
    USERS = 'users',

}

export const Menus = [
    { title: MenuName.DASHBOARD, route: RouteNames.DASHBOARD, icon: FAICONS.HOME, slug: Slug.DASHBOARD },
    { title: MenuName.USER, route: RouteNames.USER, icon: FAICONS.USER, slug: Slug.USERS },
 
];

export const AdminMenus = [
    Menus[0],
];

export const BrokerEmployeeMenu = [
    Menus[0],
];
