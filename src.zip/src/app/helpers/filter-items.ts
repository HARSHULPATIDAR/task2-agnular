/**
 * Remove blank key value from object
 * @param obj object
 */
export function removeBlankKeyValueFromObj(obj: any) {
    for (var propName in obj) {
        if (!obj[propName]) {
            delete obj[propName];
        }
    }
    return obj;
}

/**
 * Check file extentions
 */
export function isInArray(array: any, word: any) {
    return array.indexOf(word.toLowerCase()) > -1;
}

