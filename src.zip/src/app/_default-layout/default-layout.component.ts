import { Component, HostListener, OnInit } from '@angular/core';
import { SCRAPYARD, Assets, RouteNames, LOCAL_KEY, Menus } from '../_constants';
import { getLocalStorage, removeLocalStorageItems } from '../helpers';

@Component({
  selector: 'app-default-layout',
  templateUrl: './default-layout.component.html',
  styleUrls: ['./default-layout.component.scss']
})
export class DefaultLayoutComponent implements OnInit {
  userInfo: any = getLocalStorage(LOCAL_KEY.USER_DETAILS);
  sideBarMenu: any = JSON.parse(JSON.stringify(Menus));
  files: any = Assets;
  scrapyard: string = SCRAPYARD;
  screenWidth = 0;

  @HostListener('window:resize', ['$event'])
  onResize() {
    this.screenWidth = window.innerWidth;
  }

  constructor() { }

  ngOnInit(): void {
    this.onResize();
    this.setDataInitially();
  }

  /**
   * Set data initially
   */
  setDataInitially() {
    if (this.userInfo.menu_items && this.userInfo.menu_items.length > 0) {
      this.userInfo.menu_items.forEach((ele: any) => {
        this.sideBarMenu.forEach((val: any) => {
          if (ele.slug === val.slug) {
            val.is_selected = true;
            if (ele.subMenu && val.subMenu) {
              ele.subMenu.forEach((_e: any) => {
                val.subMenu.forEach((_v: any) => {
                  if (_e.slug === _v.slug) {
                    _v.is_selected = true;
                  }
                })
              });
            }
          }
        });
      });
    }
  }

  /**
   * Logout user
   */
  logout() {
    removeLocalStorageItems();
    location.href = RouteNames.LOGIN;
  }
}
