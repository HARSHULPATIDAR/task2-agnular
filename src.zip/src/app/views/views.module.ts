import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgmCoreModule } from '@agm/core';
import {
    ViewsComponent, DashboardComponent, UserComponent, UserFormComponent, 
  
} from '.';
import { ViewsRoutingModule } from './views-routing.module';
import { SharedModule } from '../_shared/shared.module';
import { MaterialModule } from '../material.module';
import { PipeModule } from "../_pipes/pipe.module";
import { LightboxModule } from 'ngx-lightbox';

import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import { FormBuilderComponent } from './form-builder/form-builder.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';




@NgModule({
    declarations: [
        ViewsComponent,
        DashboardComponent,
        UserComponent,
        UserFormComponent,
        FormBuilderComponent,
        DynamicFormComponent,
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    imports: [
        LightboxModule,
        CommonModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        ViewsRoutingModule,
        SharedModule,
        MaterialModule,
        MatButtonModule, 
        MatMenuModule, 
        MatIconModule,
        AgmCoreModule.forRoot({
           
        }),
        PipeModule
    ]
})
export class ViewsModule { }
