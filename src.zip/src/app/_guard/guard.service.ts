import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { RouteNames, LOCAL_KEY } from '../_constants';
import { getLocalStorage, removeLocalStorageItems } from '../helpers';

@Injectable({
    providedIn: 'root',
})

export class GuardService implements CanActivate {

    constructor(
        private router: Router
    ) { }

    async canActivate() {
        const token = getLocalStorage(LOCAL_KEY.TOKEN);
        const userInfo = getLocalStorage(LOCAL_KEY.USER_DETAILS)

        if (token && userInfo) {
            return true;
        } else {
            this.router.navigate([RouteNames.LOGIN]);
            removeLocalStorageItems();
            return false;
        }
    }
}
